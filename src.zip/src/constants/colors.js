export const PRIMARY = '#FFFFFF';
export const SECONDARY = '#252525';
export const ACCENT = '#6415FF';
