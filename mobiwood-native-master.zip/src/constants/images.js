export const Images = {
  Logo: require('../assets/images/logo.png'),
};
